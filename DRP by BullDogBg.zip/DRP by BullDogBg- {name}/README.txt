# Custom DRP (Custom Discord Rich Presence)

Custom DRP is a small program to use the DiscordRPC library without any knowledge of programming.

Instead just use an easy conifg file
 by BullDogBg


**Usage**

- First you need to register a Rich Presence application with discord
     
	- Go here https://discordapp.com/developers/applications/me
     
	- Make a new application **The name of the app will be the main name for the rich presence**

	- Go to Rich Presence and upload some assets.
- Run DogeDRP.exe (it should open a cmd window)
    
	-  If there are any errors from your config file It should report them in the comannd promt
- Go into discord settings and add the DogeDRP.exe as a game

- Discord should automatically change the path of DogDeRP.exe to your Discord Rich Presence


- You can edit the config any time while the program is running to change the presence


Contact me on Discord: BullDogBg#5318

Discord Servers: https://discord.gg/qnWrVfz

Discord Developer Documentation: discordapp.com/developers

YouTube: https://www.youtube.com/channel/UCeONfbdxOHKP7FR73htqVJw/featured


				Custom DRP by BullDogBg �



